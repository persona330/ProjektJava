package registry;

import modell.*;
import schleuse.*;

public class Registrieren
{
    private Schleuse<Kranke> kranke_schleuse = new Hibernate_Kranke_Schleuse();
    public Schleuse<Kranke> getKranke_schleuse() {return kranke_schleuse;}

    private Schleuse<Arzt> arzt_schleuse = new Hibernate_Arzt_Schleuse();
    public Schleuse<Arzt> getArzt_schleuse() {return  arzt_schleuse;}

    private Schleuse<Arzt.Regal> regal_schleuse = new Hibernate_Regal_Schleuse();
    public Schleuse<Arzt.Regal> getRegal_schleuse(){return  regal_schleuse;}

    private Schleuse<Arzt.Spezialisierung> spezialisierung_schleuse = new Hibernate_Spezialisierung_Schleuse();
    public Schleuse<Arzt.Spezialisierung> getSpezialisierung_schleuse(){return spezialisierung_schleuse;}

    //private Schleuse<Dokument> dokument_schleuse = new Hibernate_Dokument_Schleuse();
    //public Schleuse<Dokument> getDokument_schleuse(){return dokument_schleuse;}

    //private Schleuse<Adresse> adresse_schleuse = new Hibernate_Adresse_Schleuse();
    //public Schleuse<Adresse> getAdresse_schleuse(){return adresse_schleuse;}

    private Schleuse<Arzt.Dienststelle> dienststelle_schleuse = new Hibernate_Dienststelle_Schleuse();
    public Schleuse<Arzt.Dienststelle> getDienststelle_schleuse(){return dienststelle_schleuse;}

    //private Schleuse<Kommunkation> kommunkation_schleuse = new Hibernate_Kommunkation_Schleuse();
    //public Schleuse<Kommunkation> getKommunkation_schleuse(){return kommunkation_schleuse;}

    private Schleuse<Empfang> empfang_schleuse = new Hibernate_Empfang_Schleuse();
    public Schleuse<Empfang> getEmpfang_schleuse(){return empfang_schleuse;}

    private Schleuse<Klinik> klinik_schleuse = new Hibernate_Klinik_Schleuse();
    public Schleuse<Klinik> getKlinik_schleuse(){return klinik_schleuse;}

    private Registrieren(){}
    private static Registrieren instance = new Registrieren();
    public static Registrieren getInstance(){ return instance; }
}
