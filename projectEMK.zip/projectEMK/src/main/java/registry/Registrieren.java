package registry;

import modell.*;
import schleuse.*;

public class Registrieren
{
    private Schleuse<Kranke> kranke_schleuse = new Hibernate_Kranke_Schleuse();
    public Schleuse<Kranke> getKranke_schleuse() {return kranke_schleuse;}

    private Schleuse<Arzt> arzt_schleuse = new Hibernate_Arzt_Schleuse();
    public Schleuse<Arzt> getArzt_schleuse() {return  arzt_schleuse;}

    private Regal_Schleuse regal_schleuse = new Regal_Schleuse();
    public Regal_Schleuse getRegal_schleuse(){return  regal_schleuse;}

    private Spezialisierung_Schleuse spezialisierung_schleuse = new Spezialisierung_Schleuse();
    public Spezialisierung_Schleuse getSpezialisierung_schleuse(){return spezialisierung_schleuse;}

    private Dienststelle_Schleuse dienststelle_schleuse = new Dienststelle_Schleuse();
    public Dienststelle_Schleuse getDienststelle_schleuse(){return dienststelle_schleuse;}

    private Schleuse<Empfang> empfang_schleuse = new Hibernate_Empfang_Schleuse();
    public Schleuse<Empfang> getEmpfang_schleuse(){return empfang_schleuse;}

    private Schleuse<Klinik> klinik_schleuse = new Hibernate_Klinik_Schleuse();
    public Schleuse<Klinik> getKlinik_schleuse(){return klinik_schleuse;}

    private Registrieren(){}
    private static Registrieren instance = new Registrieren();
    public static Registrieren getInstance(){ return instance; }
}
