package schleuse;

import modell.Arzt;

public class Hibernate_Dienststelle_Schleuse extends Simple_Hibernate_Schleuse<Arzt.Dienststelle>
{
    public Hibernate_Dienststelle_Schleuse()
    {
        insert(new Arzt.Dienststelle("Врач"));
        insert(new Arzt.Dienststelle("Главврач"));
    }
}
