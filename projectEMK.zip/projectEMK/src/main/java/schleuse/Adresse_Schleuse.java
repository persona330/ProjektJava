package schleuse;

import modell.Adresse;

public class Adresse_Schleuse extends Simple_Schleuse<Adresse> {}
