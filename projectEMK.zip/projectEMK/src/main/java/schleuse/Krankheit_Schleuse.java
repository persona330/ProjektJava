package schleuse;

import modell.Diagnose;

public class Krankheit_Schleuse extends Simple_Schleuse<Diagnose.Krankheit>
{
    public Krankheit_Schleuse()
    {

    }
}
