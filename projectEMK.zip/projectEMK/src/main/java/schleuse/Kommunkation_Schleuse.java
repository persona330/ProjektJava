package schleuse;

import modell.Kommunkation;

public class Kommunkation_Schleuse extends Simple_Schleuse<Kommunkation> {
}
