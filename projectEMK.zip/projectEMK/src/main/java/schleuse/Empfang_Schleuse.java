package schleuse;

import modell.Empfang;

public class Empfang_Schleuse extends Simple_Schleuse<Empfang>
{
}
