package schleuse;

import exceptions.Nein_Essenz;
import utils.EntityManagerFactoryUtil;

import javax.persistence.EntityManager;
import java.lang.reflect.ParameterizedType;
import java.util.List;


public class Simple_Hibernate_Schleuse<T> implements Schleuse<T>
{
    /** В Java Persistence используется EntityManager - интерфейс для создания единиц работы - набор операций, меняющих
     * (возможно) состояние которые выполняются (обычно атомарно) как единое целое.
     * Экземпляр EntityManagerFactory - одна единица хранения или одна логическая база данных. */
    private EntityManager entityManager = EntityManagerFactoryUtil.getEntityManager();
    private Class<T> persistentClass;

    /** Аннотация для подавления предупреждений компилятора об небезопасности выполнения непроверенных операциях,
     * таких как приведение типов. */
    @SuppressWarnings("unchecked")
    public Simple_Hibernate_Schleuse() { this.persistentClass = (Class<T>) ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0]; }

    @Override
    @SuppressWarnings("unchecked")
    public List<T> all() { return entityManager.createQuery("Select t from " + persistentClass.getSimpleName() + " t").getResultList(); }

    @Override
    public T find(Long id) throws Nein_Essenz
    {
        T person = entityManager.find(persistentClass, id);
        if (person == null)
            throw new Nein_Essenz(String.format("Entity with id=%d not found", id ));
        return person;
    }

    @Override
    public void insert(T object)
    {
        entityManager.getTransaction().begin();
        entityManager.persist(object);
        entityManager.getTransaction().commit();
    }

    @Override
    public void update(T object) throws Nein_Essenz
    {
        entityManager.getTransaction().begin();
        entityManager.merge(object);
        entityManager.getTransaction().commit();
    }

    @Override
    public void delete(T ob)
    {
        entityManager.getTransaction().begin();
        entityManager.remove(ob);
        entityManager.getTransaction().commit();
    }
}
