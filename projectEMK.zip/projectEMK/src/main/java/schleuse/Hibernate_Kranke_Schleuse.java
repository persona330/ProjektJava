package schleuse;

import modell.Kranke;

public class Hibernate_Kranke_Schleuse extends Simple_Hibernate_Schleuse<Kranke> {
}
