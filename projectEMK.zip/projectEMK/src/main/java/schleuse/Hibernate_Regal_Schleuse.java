package schleuse;

import modell.Arzt;

public class Hibernate_Regal_Schleuse extends Simple_Hibernate_Schleuse<Arzt.Regal>
{
    public Hibernate_Regal_Schleuse(){
        insert(new Arzt.Regal("Нет"));
        insert(new Arzt.Regal("Международная премия Гайрднера"));
        insert(new Arzt.Regal("Заслуженный врач Российской Федерации"));
        insert(new Arzt.Regal("Золотой скальпель"));
        insert(new Arzt.Regal("Кимберовская премия"));
        insert(new Arzt.Regal("Премия Альберта Ласкера за фундаментальные медицинские исследования"));
        insert(new Arzt.Regal("Лауреаты премии Вольфа (медицина)"));
        insert(new Arzt.Regal("Медаль Грефе"));
        insert(new Arzt.Regal("Медаль Котениуса"));
        insert(new Arzt.Regal("Медаль Мхитара Гераци"));
        insert(new Arzt.Regal("Медаль Роберта Коха"));
        insert(new Arzt.Regal("Премия имени Л. А. Орбели"));
        insert(new Arzt.Regal("Премии Хейнекена"));
        insert(new Arzt.Regal("Премия Алана Уотермана"));
        insert(new Arzt.Regal("Премия Вильяма Коли"));
        insert(new Arzt.Regal("Премия Диксона"));
        insert(new Arzt.Regal("Премия за прорыв в области медицины"));
        insert(new Arzt.Regal("Премия имени А. Н. Бакулева"));
        insert(new Arzt.Regal("Премия Ласкера"));
        insert(new Arzt.Regal("Премия Ласкера — Дебейки за клинические медицинские исследования"));
        insert(new Arzt.Regal("Премия Лемельсона"));
        insert(new Arzt.Regal("Премия Луизы Гросс Хорвиц"));
        insert(new Arzt.Regal("Премия медицинского центра Олбани"));
        insert(new Arzt.Regal("Премия Мэссри"));
        insert(new Arzt.Regal("Премия Роберта Коха"));
        insert(new Arzt.Regal("Премия Тан"));
        insert(new Arzt.Regal("Премия Шао"));
        insert(new Arzt.Regal("Профессия — жизнь"));
        insert(new Arzt.Regal("Премия Розенстила"));
        insert(new Arzt.Regal("Список лауреатов Нобелевской премии по физиологии или медицине"));
        insert(new Arzt.Regal("Премия имени А. А. Ухтомского"));
        insert(new Arzt.Regal("Премия Харви"));
        insert(new Arzt.Regal("BBVA Foundation Frontiers of Knowledge Award"));
        insert(new Arzt.Regal("Beering Award"));
        insert(new Arzt.Regal("Warren Triennial Prize"));
    }
}
