package schleuse;

import exceptions.Nein_Essenz;

import java.util.List;

public interface Schleuse<T> // Интерфейс коллекции обьектов
{
    List<T> all();
    T find(Long id) throws Nein_Essenz;
    void insert(T objevt);
    void update(T object) throws Nein_Essenz;
    void delete(T obj);
}
