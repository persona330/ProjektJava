package schleuse;

import modell.Arzt;

public class Arzt_Schleuse extends Simple_Schleuse<Arzt> {}
