package schleuse;

import modell.Kranke;

public class Kranke_Schleuse extends Simple_Schleuse<Kranke> {}
