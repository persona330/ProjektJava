package schleuse;

import modell.Mensch;

public class Mensch_Schleuse extends Simple_Schleuse<Mensch> {}
