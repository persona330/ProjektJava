package schleuse;

import modell.Arzt;

public class Hibernate_Spezialisierung_Schleuse extends Simple_Hibernate_Schleuse<Arzt.Spezialisierung> {}
