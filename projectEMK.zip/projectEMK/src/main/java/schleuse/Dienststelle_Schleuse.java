package schleuse;

import modell.Arzt;

public class Dienststelle_Schleuse extends Simple_Schleuse<Arzt.Dienststelle>
{
    public Dienststelle_Schleuse()
    {
        insert(new Arzt.Dienststelle("Врач"));
        insert(new Arzt.Dienststelle("Главврач"));
    }
}
