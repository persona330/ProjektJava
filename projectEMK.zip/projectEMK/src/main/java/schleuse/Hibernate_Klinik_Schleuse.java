package schleuse;

import modell.Klinik;

public class Hibernate_Klinik_Schleuse extends Simple_Hibernate_Schleuse<Klinik>
{
}
