package schleuse;

import modell.Klinik;

public class Klinik_Schleuse extends Simple_Schleuse<Klinik>
{
}
