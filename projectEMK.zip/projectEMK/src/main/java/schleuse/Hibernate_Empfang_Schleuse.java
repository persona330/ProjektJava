package schleuse;

import modell.Empfang;

public class Hibernate_Empfang_Schleuse extends Simple_Hibernate_Schleuse<Empfang>
{
}
