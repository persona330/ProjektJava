package modell;

import javafx.beans.property.SimpleListProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.ObservableList;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Access(AccessType.PROPERTY)
@Table(name = "BEHANDLUNG")
public class Behandlung
{
    private long id_behandlung;
    private StringProperty startdatum = new SimpleStringProperty();
    private StringProperty enddatum = new SimpleStringProperty();
    private StringProperty methode = new SimpleStringProperty();
    private StringProperty form_b = new SimpleStringProperty();
    private StringProperty name_b = new SimpleStringProperty();
    private StringProperty dosis = new SimpleStringProperty();

    @ManyToMany(mappedBy = "behandlungen", fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
    private Set<Empfang> empfangen = new HashSet<>();

    public Behandlung(String startdatum, String enddatum, String methode, String form_b, String name_b, String dosis)
    {
        this.startdatum.set(startdatum);
        this.enddatum.set(enddatum);
        this.methode.set(methode);
        this.form_b.set(form_b);
        this.name_b.set(name_b);
        this.dosis.set(dosis);
    }
    public Behandlung(long id_behandlung, String startdatum, String enddatum, String methode, String form_b, String name_b, String dosis)
    {
        this.startdatum.set(startdatum);
        this.enddatum.set(enddatum);
        this.methode.set(methode);
        this.form_b.set(form_b);
        this.name_b.set(name_b);
        this.dosis.set(dosis);
    }
    public Behandlung(){}

    @Column(name = "Startdatum", table = "BEHANDLUNG", nullable = false)
    @Type(type = "text")
    public String getStartdatum() { return startdatum.get(); }
    @Transient
    public StringProperty startdatumProperty() { return startdatum; }
    public void setStartdatum(String startdatum) { this.startdatum.set(startdatum); }

    @Column(name = "Enddatum", nullable = false)
    @Type(type = "text")
    public String getEnddatum() { return enddatum.get(); }
    @Transient
    public StringProperty enddatumProperty() { return enddatum; }
    public void setEnddatum(String enddatum) { this.enddatum.set(enddatum); }

    @Column(name = "Methode", nullable = false)
    @Type(type = "text")
    public String getMethode() { return methode.get(); }
    @Transient
    public StringProperty methodeProperty() { return methode; }
    public void setMethode(String methode) { this.methode.set(methode); }

    @Column(name = "Form", nullable = false)
    @Type(type = "text")
    public String getForm_b() { return form_b.get(); }
    @Transient
    public StringProperty form_bProperty() { return form_b; }
    public void setForm_b(String form_b) { this.form_b.set(form_b); }

    @Column(name = "Name", nullable = false)
    @Type(type = "text")
    public String getName_b() { return name_b.get(); }
    @Transient
    public StringProperty name_bProperty() { return name_b; }
    public void setName_b(String name_b) { this.name_b.set(name_b); }

    @Column(name = "Dosis", nullable = false)
    @Type(type = "text")
    public String getDosis() { return dosis.get(); }
    @Transient
    public StringProperty dosisProperty() { return dosis; }
    public void setDosis(String dosis) { this.dosis.set(dosis); }

    @Id
    @GeneratedValue(generator = "sqliteBehandlung", strategy = GenerationType.AUTO)
    @Column(name = "ID_Behandlung", unique = true, nullable = false)
    public long getId() { return id_behandlung; }
    public void setId(long id_behandlung) {
        this.id_behandlung = id_behandlung;
    }

    @Override
    public String toString(){ return getStartdatum() + " " + getEnddatum() + " " + getMethode() + " " + getForm_b() + " " + getName_b() + " " + getDosis(); }
}
