package modell;

import javafx.beans.property.*;
import javafx.collections.ObservableList;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.*;

@Entity
@Access(AccessType.PROPERTY)
@Table(name = "ARZT")
public class Arzt extends Mensch // Врач
{
//______________________________________________________________________________________________________________________
    @Entity
    @Access(AccessType.PROPERTY)
    @Table(name = "REGAL")
    public static class Regal  // Регалия
    {
        private long id_regal;
        private StringProperty name_r = new SimpleStringProperty();

        @Access(AccessType.FIELD)
        @ManyToMany(mappedBy = "regalen", fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
        private Set<Arzt> arzt = new HashSet<>();

        public Regal(String name_r) { this.name_r.set(name_r); }
        public Regal(long id_regal, String name_r) { this.name_r.set(name_r); }
        public Regal(){}

        @Column(name = "Name", nullable = false)
        @Type(type = "text")
        public String getName_r() { return name_r.get(); }
        @Transient
        public StringProperty name_rProperty() { return name_r; }
        public void setName_r(String name_r) { this.name_r.set(name_r); }

        public Set<Arzt> getArzt() { return arzt; }
        public void setArzt(Set<Arzt> arzt) { this.arzt = arzt; }

        @Id
        @GeneratedValue(generator = "sqliteRegal", strategy = GenerationType.AUTO)
        @Column(name = "ID_Regal", unique = true, nullable = false)
        public long getId() { return id_regal; }
        public void setId(long id_regal) {
            this.id_regal = id_regal;
        }

        @Override
        public String toString(){
            return getName_r();
        }
    }
    //------------------------------------------------------------------------------------------------------------------
    @Entity
    @Access(AccessType.PROPERTY)
    @Table(name = "SPEZIALISIERUNG")
    public static class Spezialisierung // Специализация
    {
        private long id_spezialisierung;
        private StringProperty name_s = new SimpleStringProperty();

        @Access(AccessType.FIELD)
        @ManyToMany(mappedBy = "spezialisierungen", fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
        private Set<Arzt> arzten = new HashSet<>();

        public Spezialisierung(String name_s) { this.name_s.set(name_s); }
        public Spezialisierung(long id_spezialisierung, String name_s) { this.name_s.set(name_s); }
        public Spezialisierung(){}

        @Column(name = "Name", nullable = false)
        @Type(type = "text")
        public String getName_s() { return name_s.get(); }
        @Transient
        public StringProperty name_sProperty() { return name_s; }
        public void setName_s(String name_s) { this.name_s.set(name_s); }

        public Set<Arzt> getArzten() { return arzten; }
        public void setArzten(Set<Arzt> arzten) { this.arzten = arzten; }

        @Id
        @GeneratedValue(generator = "sqliteSpezialisierung", strategy = GenerationType.AUTO)
        @Column(name = "ID_Spezialisierung", unique = true, nullable = false)
        public long getId() { return id_spezialisierung; }
        public void setId(long id_spezialisierung) {
            this.id_spezialisierung = id_spezialisierung;
        }

        @Override
        public String toString(){
            return getName_s();
        }
    }
    //------------------------------------------------------------------------------------------------------------------
    @Entity
    @Access(AccessType.PROPERTY)
    @Table(name = "DIENSTSTELLE")
    public static class Dienststelle // Должность
    {
        private long id_dienststelle;
        private StringProperty name_d = new SimpleStringProperty();

        @Access(AccessType.FIELD)
        @OneToMany(mappedBy = "dienststelle", fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
        private Set<Arzt> arzten = new HashSet<>();

        public Dienststelle(String name_d) { this.name_d.set(name_d); }
        public Dienststelle(long id_dienststelle, String name_d) { this.name_d.set(name_d); }
        public Dienststelle(){}

        @Column(name = "Name", nullable = false)
        @Type(type = "text")
        public String getName_d() { return name_d.get(); }
        @Transient
        public StringProperty name_dProperty() { return name_d; }
        public void setName_d(String name_d) { this.name_d.set(name_d); }

        public Set<Arzt> getArzten() { return arzten; }
        public void setArzten(Set<Arzt> arzten) { this.arzten = arzten; }

        @Id
        @GeneratedValue(generator = "sqliteDienststelle", strategy = GenerationType.AUTO)
        @Column(name = "ID_Dienststelle", unique = true, nullable = false)
        public long getId() { return id_dienststelle; }
        public void setId(long id_dienststelle) {
            this.id_dienststelle = id_dienststelle;
        }

        @Override
        public String toString(){
            return getName_d();
        }
    }
//______________________________________________________________________________________________________________________
    @Access(AccessType.FIELD)
    @ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
    @JoinTable(name = "ARZT_REGAL", joinColumns = @JoinColumn(name = "ID_Regal"), inverseJoinColumns = @JoinColumn(name = "ID_Arzt", nullable = false))
    private List<Regal> regalen = new ArrayList<>();
    @Access(AccessType.FIELD)
    @ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
    @JoinTable(name = "ARZT_SPEZIALISIERUNG", joinColumns = @JoinColumn(name = "ID_Spezialisierung"), inverseJoinColumns = @JoinColumn(name = "ID_Arzt", nullable = false))
    private List<Spezialisierung> spezialisierungen = new ArrayList<>();
    @Access(AccessType.FIELD)
    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
    @JoinColumn(name = "Dienststelle", nullable = false)
    private Dienststelle dienststelle;
    @Access(AccessType.FIELD)
    @OneToMany(mappedBy = "arzt", fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
    private Set<Empfang> empfangen = new HashSet<>();

    public Arzt(String nachname, String vorname, String zweiter_vorname, String geburtsdatum, int alter, String geschlecht, Adresse adresse, Kommunkation kommunkation, List<Regal> regalen, List<Spezialisierung> spezialisierungen, Dienststelle dienststelle, Set<Empfang> empfangen)
    {
        super(nachname, vorname, zweiter_vorname, kommunkation);
        this.regalen = regalen;
        this.spezialisierungen = spezialisierungen;
        this.dienststelle = dienststelle;
        this.empfangen = empfangen;
    }
    public Arzt(long id, String nachname, String vorname, String zweiter_vorname, String geburtsdatum, int alter, String geschlecht, Adresse adresse, Kommunkation kommunkation, List<Regal> regalen, List<Spezialisierung> spezialisierungen, Dienststelle dienststelle, Set<Empfang> empfangen)
    {
        super(id, nachname, vorname, zweiter_vorname, kommunkation);
        this.regalen = regalen;
        this.spezialisierungen = spezialisierungen;
        this.dienststelle = dienststelle;
        this.empfangen = empfangen;
    }
    public Arzt(){}

    public List<Regal> getRegalen() { return regalen; }
    public void setRegalen(List<Regal> regalen) { this.regalen = regalen; }

    public List<Spezialisierung> getSpezialisierungen() { return spezialisierungen; }
    public void setSpezialisierungen(List<Spezialisierung> spezialisierungen) { this.spezialisierungen = spezialisierungen; }

    public Dienststelle getDienststelle() { return dienststelle; }
    public void setDienststelle(Dienststelle dienststelle) { this.dienststelle = dienststelle; }

    public Set<Empfang> getEmpfangen() { return empfangen; }
    public void setEmpfangen(Set<Empfang> empfangen) {this.empfangen = empfangen; }
}
