package modell;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import org.hibernate.annotations.Type;

import javax.persistence.*;

@Entity
@Access(AccessType.PROPERTY)
@Table(name = "KOMMUNKATION")
public class Kommunkation
{
    public long id_kommunkation;
    private StringProperty e_mail = new SimpleStringProperty();
    private IntegerProperty telefon = new SimpleIntegerProperty();

    public Kommunkation(String e_mail, Integer telefon)
    {
        this.e_mail.set(e_mail);
        this.telefon.set(telefon);
    }
    public Kommunkation(long id_kommunkation, String e_mail, Integer telefon)
    {
        this.e_mail.set(e_mail);
        this.telefon.set(telefon);
    }
    public Kommunkation(){}

    @Column(name = "E_mail")
    @Type(type = "text")
    public String getE_mail() { return e_mail.get(); }
    @Transient
    public StringProperty e_mailProperty() { return e_mail; }
    public void setE_mail(String e_mail) { this.e_mail.set(e_mail); }

    @Column(name = "Telefon")
    @Type(type = "int")
    public int getTelefon() { return telefon.get(); }
    @Transient
    public IntegerProperty telefonProperty() { return telefon; }
    public void setTelefon(int telefon) { this.telefon.set(telefon); }

    @Id
    @GeneratedValue(generator = "sqliteKommunkation", strategy = GenerationType.AUTO)
    @Column(name = "ID_Kommunkation", unique = true, nullable = false)
    public long getId() { return id_kommunkation; }
    public void setId(long id_kommunkation) {
        this.id_kommunkation = id_kommunkation;
    }

    @Override
    public String toString(){ return getE_mail() + " " + getTelefon();}
    }
