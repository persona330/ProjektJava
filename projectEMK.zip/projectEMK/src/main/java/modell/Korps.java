package modell;

import javafx.beans.property.*;
import javafx.collections.ObservableList;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Access(AccessType.PROPERTY)
@Table(name = "KORPS")
public class Korps
{
//______________________________________________________________________________________________________________________
    @Entity
    @Access(AccessType.PROPERTY)
    @Table(name = "ABTEIL")
    public static class Abteil  // Отеделение
    {
        private long id_abteil;
        private StringProperty name_ab = new SimpleStringProperty();

        @Access(AccessType.FIELD)
        @ManyToMany(mappedBy = "abteilen", fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
        private Set<Korps> korpsen = new HashSet<>();
        @Access(AccessType.FIELD)
        @OneToMany(mappedBy = "abteil", fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
        private Set<Arbeitszimmer> arbeitszimmeren = new HashSet<>();

        public Abteil(String name_ab, Set<Arbeitszimmer> arbeitszimmeren, Set<Korps> korpsen)
        {
            this.name_ab.set(name_ab);
            this.arbeitszimmeren = arbeitszimmeren;
            this.korpsen = korpsen;
        }
        public Abteil(long id_abteil, String name_ab, Set<Arbeitszimmer> arbeitszimmeren, Set<Korps> korpsen)
        {
            this.name_ab.set(name_ab);
            this.arbeitszimmeren = arbeitszimmeren;
            this.korpsen = korpsen;
        }

        public Abteil(){}

        @Column(name = "Name")
        @Type(type = "text")
        public String getName_ab() { return name_ab.get(); }
        @Transient
        public StringProperty name_abProperty() { return name_ab; }
        public void setName_ab(String name_ab) { this.name_ab.set(name_ab); }

        public Set<Korps> getKorpsen() { return korpsen; }
        public void setKorpsen(Set<Korps> korpsen) { this.korpsen = korpsen; }

        public Set<Arbeitszimmer> getArbeitszimmeren() { return arbeitszimmeren; }
        public void setArbeitszimmeren(Set<Arbeitszimmer> arbeitszimmeren) { this.arbeitszimmeren = arbeitszimmeren; }

        @Id
        @GeneratedValue(generator = "sqliteAbteil", strategy = GenerationType.AUTO)
        @Column(name = "ID_Abteil", unique = true, nullable = false)
        public long getId() { return id_abteil; }
        public void setId(long id_abteil) {
            this.id_abteil = id_abteil;
        }
    }
    //------------------------------------------------------------------------------------------------------------------
    @Entity
    @Access(AccessType.PROPERTY)
    @Table(name = "ARBEITSZIMMER")
    public static class Arbeitszimmer // Кабинет (Внутренний класс)
    {
        private long id_arbeitszimmer;
        private StringProperty nummer_arb = new SimpleStringProperty();

        @Access(AccessType.FIELD)
        @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
        @JoinColumn(name = "Korps")
        private Korps korps;
        @Access(AccessType.FIELD)
        @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
        @JoinColumn(name = "Abteil")
        private Abteil abteil;

        public Arbeitszimmer(String nummer_arb, Abteil abteil, Korps korps)
        {
            this.nummer_arb.set(nummer_arb);
            this.abteil = abteil;
            this.korps = korps;
        }
        public Arbeitszimmer(long id_arbeitszimmer, String nummer_arb, Abteil abteil, Korps korps)
        {
            this.nummer_arb.set(nummer_arb);
            this.abteil = abteil;
            this.korps = korps;
        }
        public Arbeitszimmer(){}

        @Column(name = "Nummer")
        @Type(type = "text")
        public String getNummer_arb() { return nummer_arb.get(); }
        @Transient
        public StringProperty nummer_arbProperty() { return nummer_arb; }
        public void setNummer_arb(String nummer_arb) { this.nummer_arb.set(nummer_arb); }

        public Korps getKorps() { return korps; }
        public void setKorps(Korps korps) { this.korps = korps; }

        public Abteil getAbteil() { return abteil; }
        public void setAbteil(Abteil abteil) { this.abteil = abteil; }

        @Id
        @GeneratedValue(generator = "sqliteArbeitszimmer", strategy = GenerationType.AUTO)
        @Column(name = "ID_Arbeitszimmer", unique = true, nullable = false)
        public long getId() { return id_arbeitszimmer; }
        public void setId(long id_arbeitszimmer) {
            this.id_arbeitszimmer = id_arbeitszimmer;
        }
    }
//______________________________________________________________________________________________________________________
    private long id_korps;
    private StringProperty nummer_ko = new SimpleStringProperty();

    @Access(AccessType.FIELD)
    @OneToMany(mappedBy = "korps", fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
    private Set<Arbeitszimmer> arbeitszimmeren = new HashSet<>();

    @Access(AccessType.FIELD)
    @ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
    @JoinTable(name = "KORPS_ABTEIL", joinColumns = @JoinColumn(name = "ID_Abteil"), inverseJoinColumns = @JoinColumn(name = "ID_Korps", nullable = false))
    private Set<Abteil> abteilen = new HashSet<>();

    @Access(AccessType.FIELD)
    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
    @JoinTable(name = "KORPS_ADRESSE", joinColumns = @JoinColumn(name = "ID_Korps"), inverseJoinColumns = @JoinColumn(name = "ID_Adresse" , nullable = false))
    private Adresse adresse;

    @Access(AccessType.FIELD)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "Klinik")
    private Klinik klinik;

    public Korps(String nummer_ko, Adresse adresse, Set<Arbeitszimmer> arbeitszimmeren, Set<Abteil> abteilen)
    {
        this.nummer_ko.set(nummer_ko);
        this.adresse = adresse;
        this.arbeitszimmeren = arbeitszimmeren;
        this.abteilen = abteilen;
    }
    public Korps(long id_korps, String nummer_ko, Adresse adresse, Set<Arbeitszimmer> arbeitszimmeren, Set<Abteil> abteilen)
    {
        this.nummer_ko.set(nummer_ko);
        this.adresse = adresse;
        this.arbeitszimmeren = arbeitszimmeren;
        this.abteilen = abteilen;
    }
    public Korps(){}

    @Column(name = "Nummer")
    @Type(type = "text")
    public String getNummer_ko() { return nummer_ko.get(); }
    @Transient
    public StringProperty nummer_koProperty() { return nummer_ko; }
    public void setNummer_ko(String nummer_ko) { this.nummer_ko.set(nummer_ko); }

    public Adresse getAdresse() { return adresse; }
    public void setAdresse(Adresse adresse) { this.adresse = adresse; }

    public Set<Arbeitszimmer> getArbeitszimmeren() { return arbeitszimmeren; }
    public void setArbeitszimmeren(Set<Arbeitszimmer> arbeitszimmeren) { this.arbeitszimmeren = arbeitszimmeren; }

    public Set<Abteil> getAbteilen() { return abteilen; }
    public void setAbteilen(Set<Abteil> abteilen) { this.abteilen = abteilen; }

    @Id
    @GeneratedValue(generator = "sqliteKorps", strategy = GenerationType.AUTO)//length = 100
    @Column(name = "ID_Korps", unique = true, nullable = false)
    public long getId() { return id_korps; }
    public void setId(long id_korps) {
        this.id_korps = id_korps;
    }

    @Override
    public String toString(){ return getNummer_ko();}
}
