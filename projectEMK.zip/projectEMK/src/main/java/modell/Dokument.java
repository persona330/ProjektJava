package modell;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import org.hibernate.annotations.Type;

import javax.persistence.*;

@Entity
@Access(AccessType.PROPERTY)
@Table(name = "DOKUMENT")
public class Dokument
{
    private long id_dokument;
    private StringProperty name_d = new SimpleStringProperty();
    private IntegerProperty serie = new SimpleIntegerProperty();
    private IntegerProperty nummer_d = new SimpleIntegerProperty();
    private StringProperty ausgestellt_von = new SimpleStringProperty();
    private StringProperty datum_ausstellung = new SimpleStringProperty();

    @Access(AccessType.FIELD)
    @OneToOne(mappedBy = "dokument", fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
    private Kranke kranke;
    @Access(AccessType.FIELD)
    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
    @JoinColumn(name = "Klinik")
    private Klinik klinik;

    public Dokument(String name_d, int serie, int nummer_d, String ausgestellt_von, String datum_ausstellung)
    {
        this.name_d.set(name_d);
        this.serie.set(serie);
        this.nummer_d.set(nummer_d);
        this.ausgestellt_von.set(ausgestellt_von);
        this.datum_ausstellung.set(datum_ausstellung);
    }
    public Dokument(long id_dokument, String name_d, int serie, int nummer_d, String ausgestellt_von, String datum_ausstellung)
    {
        this.name_d.set(name_d);
        this.serie.set(serie);
        this.nummer_d.set(nummer_d);
        this.ausgestellt_von.set(ausgestellt_von);
        this.datum_ausstellung.set(datum_ausstellung);
    }
    public Dokument(){}
    public Dokument(String name_d) { this.name_d.set(name_d); }

    @Column(name = "Name")
    @Type(type = "text")
    public String getName_d() { return name_d.get(); }
    @Transient
    public StringProperty name_dProperty() { return name_d; }
    public void setName_d(String name_d) { this.name_d.set(name_d); }

    @Column(name = "Serie")
    @Type(type = "int")
    public int getSerie() { return serie.get(); }
    @Transient
    public IntegerProperty serieProperty() { return serie; }
    public void setSerie(int serie) { this.serie.set(serie); }

    @Column(name = "Nummer")
    @Type(type = "int")
    public int getNummer_d() { return nummer_d.get(); }
    @Transient
    public IntegerProperty nummer_dProperty() { return nummer_d; }
    public void setNummer_d(int nummer_d) { this.nummer_d.set(nummer_d); }

    @Column(name = "Ausgestellt_von")
    @Type(type = "text")
    public String getAusgestellt_von() { return ausgestellt_von.get(); }
    @Transient
    public StringProperty ausgestellt_vonProperty() { return ausgestellt_von; }
    public void setAusgestellt_von(String ausgestellt_von) { this.ausgestellt_von.set(ausgestellt_von); }

    @Column(name = "Datum_ausstellung")
    @Type(type = "text")
    public String getDatum_ausstellung() { return datum_ausstellung.get(); }
    @Transient
    public StringProperty datum_ausstellungProperty() { return datum_ausstellung; }
    public void setDatum_ausstellung(String datum_ausstellung) { this.datum_ausstellung.set(datum_ausstellung); }

    @Id
    @GeneratedValue(generator = "sqliteDokument", strategy = GenerationType.AUTO)
    @Column(name = "ID_Dokument", unique = true, nullable = false)
    public long getId() { return id_dokument; }
    public void setId(long id_dokument) {
        this.id_dokument = id_dokument;
    }

    @Override
    public String toString(){ return getName_d() + " " + getSerie() + " " + getNummer_d() + " " + getAusgestellt_von() + " " + getDatum_ausstellung();}

}
