package modell;

import javafx.beans.property.*;
import net.bytebuddy.asm.Advice;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Set;

@Entity
@Access(AccessType.PROPERTY)
@Table(name = "KRANKE")
public class Kranke extends Mensch
{
    private StringProperty beschaftigung = new SimpleStringProperty(); // занятость
    private ObjectProperty<Date> geburtsdatum = new SimpleObjectProperty<>();
    private IntegerProperty alter = new SimpleIntegerProperty();
    private StringProperty geschlecht = new SimpleStringProperty();

    @Access(AccessType.FIELD)
    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
    @JoinTable(name = "KRANKE_DOKUMENT", joinColumns = @JoinColumn(name = "ID"), inverseJoinColumns = @JoinColumn(name = "ID_Dokument", nullable = false))
    private Dokument dokument;
    @Access(AccessType.FIELD)
    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
    @JoinColumn(name = "Adresse")
    protected Adresse adresse;

    public Kranke(String nachname, String vorname, String zweiter_vorname, Date geburtsdatum, int alter, String geschlecht, String beschaftigung, Adresse adresse, Kommunkation kommunkation, Dokument dokument)
    {
        super(nachname, vorname, zweiter_vorname, kommunkation);
        this.beschaftigung.set(beschaftigung);
        this.geburtsdatum.set(geburtsdatum);
        this.alter.set(alter);
        this.geschlecht.set(geschlecht);
        this.adresse = adresse;
        this.dokument = dokument;
    }
    public Kranke(long id, String nachname, String vorname, String zweiter_vorname, Date geburtsdatum, int alter, String geschlecht, String beschaftigung, Adresse adresse, Kommunkation kommunkation, Dokument dokument)
    {
        super(id, nachname, vorname, zweiter_vorname, kommunkation);
        this.beschaftigung.set(beschaftigung);
        this.geburtsdatum.set(geburtsdatum);
        this.alter.set(alter);
        this.geschlecht.set(geschlecht);
        this.adresse = adresse;
        this.dokument = dokument;
    }
    public Kranke() {}

    @Column (name = "Beschaftigung")
    @Type(type = "text")
    public String getBeschaftigung() { return beschaftigung.get(); }
    @Transient
    public StringProperty beschaftigungProperty() { return beschaftigung; }
    public void setBeschaftigung(String beschaftigung) { this.beschaftigung.set(beschaftigung); }

    @Column (name = "Geburtsdatum")
    @Type(type = "text")
    public Date getGeburtsdatum() { return geburtsdatum.get(); }
    @Transient
    public ObjectProperty<Date> geburtsdatumProperty() { return geburtsdatum; }
    public void setGeburtsdatum(Date geburtsdatum) { this.geburtsdatum.set(geburtsdatum); }

    @Column (name = "Alter_Kr")
    @Type(type = "int")
    public int getAlter() { return alter.get(); }
    @Transient
    public IntegerProperty alterProperty() { return alter; }
    public void setAlter(int alter) { this.alter.set(alter); }

    @Column (name = "Geschlecht", nullable = false)
    @Type(type = "text")
    public String getGeschlecht() { return geschlecht.get(); }
    @Transient
    public StringProperty geschlechtProperty() { return geschlecht; }
    public void setGeschlecht(String geschlecht) { this.geschlecht.set(geschlecht); }

    public Dokument getDokument() { return dokument;}
    public void setDokument(Dokument dokument) { this.dokument = dokument; }

    public Adresse getAdresse() { return adresse; }
    public void setAdresse(Adresse adresse) { this.adresse = adresse; }

}
