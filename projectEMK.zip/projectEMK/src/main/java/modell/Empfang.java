package modell;

import javafx.beans.property.*;
import javafx.collections.ObservableList;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Access(AccessType.PROPERTY)
@Table(name = "EMPFANG")
public class Empfang
{
    private long id_empfang;
    private StringProperty zeit_e = new SimpleStringProperty();
    private StringProperty datum_e = new SimpleStringProperty();

    @Access(AccessType.FIELD)
    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
    @JoinColumn(name = "Diagnose")
    private Diagnose diagnose;
    @Access(AccessType.FIELD)
    @ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
    @JoinTable(name = "EMPFANG_BEHANDLUNG", joinColumns = @JoinColumn(name = "ID_Empfang"), inverseJoinColumns = @JoinColumn(name = "ID_Behandlung", nullable = false))
    private List<Behandlung> behandlungen = new ArrayList<>();
    @Access(AccessType.FIELD)
    @ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
    @JoinTable(name = "EMPFANG_FORSCHUNG", joinColumns = @JoinColumn(name = "ID_Empfang"), inverseJoinColumns = @JoinColumn(name = "ID_Forschung", nullable = false))
    private List<Forschung> forschungen = new ArrayList<>();
    @Access(AccessType.FIELD)
    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
    @JoinColumn(name = "Arzt")
    private Arzt arzt;

    public Empfang(String zeit_e, String datum_e, Diagnose diagnose, List<Behandlung> behandlungen, List<Forschung> forschungen)
    {
        this.zeit_e.set(zeit_e);
        this.datum_e.set(datum_e);
        this.diagnose = diagnose;
        this.behandlungen = behandlungen;
        this.forschungen = forschungen;
    }
    public Empfang(long id_empfang, String zeit_e, String datum_e, Diagnose diagnose, List<Behandlung> behandlungen, List<Forschung> forschungen)
    {
        this.zeit_e.set(zeit_e);
        this.datum_e.set(datum_e);
        this.diagnose = diagnose;
        this.behandlungen = behandlungen;
        this.forschungen = forschungen;
    }
    public Empfang(){}

    @Column (name = "Zeit")
    @Type(type = "text")
    public String getZeit_e() { return zeit_e.get(); }
    @Transient
    public StringProperty zeit_eProperty() { return zeit_e; }
    public void setZeit_e(String zeit_e) { this.zeit_e.set(zeit_e); }

    @Column (name = "Datum", nullable = false)
    @Type(type = "text")
    public String getDatum_e() { return datum_e.get(); }
    @Transient
    public StringProperty datum_eProperty() { return datum_e; }
    public void setDatum_e(String datum_e) { this.datum_e.set(datum_e); }

    public Diagnose getDiagnose() { return diagnose; }
    public void setDiagnose(Diagnose diagnose) { this.diagnose = diagnose; }

    public List<Behandlung> getBehandlungen() { return behandlungen; }
    public void setBehandlungen(List<Behandlung> behandlungen) { this.behandlungen = behandlungen; }

    public List<Forschung> getForschungen() { return forschungen; }
    public void setForschungen(List<Forschung> forschungen) { this.forschungen = forschungen; }

    @Id
    @GeneratedValue(generator = "sqliteEmpfang", strategy = GenerationType.AUTO)
    @Column(name = "ID_Empfang", unique = true, nullable = false)
    public long getId() { return id_empfang; }
    public void setId(long id_empfang) { this.id_empfang = id_empfang; }

    @Override
    public String toString(){ return getZeit_e() + " " + getDatum_e();}
}
