package modell;

import javafx.beans.property.*;
import javafx.collections.ObservableList;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Access(AccessType.PROPERTY)
@Table(name = "DIAGNOSE")
public class Diagnose
{
    @Entity
    @Access(AccessType.PROPERTY)
    @Table(name = "KRANKHEIT")
    public static class Krankheit
    {
        public long id_krankheit;
        private StringProperty name_kh = new SimpleStringProperty();
        private StringProperty stadium = new SimpleStringProperty();

        @ManyToMany(mappedBy = "krankheiten", fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
        private Set<Diagnose> diagnosen = new HashSet<>();

        public Krankheit(String name_kh, String stadium)
        {
            this.name_kh.set(name_kh);
            this.stadium.set(stadium);
        }
        public Krankheit(long id_krankheit, String name_kh, String stadium)
        {
            this.name_kh.set(name_kh);
            this.stadium.set(stadium);
        }
        public Krankheit(){}

        @Column(name = "Name", nullable = false)
        @Type(type = "text")
        public String getName_kh() { return name_kh.get(); }
        @Transient
        public StringProperty name_khProperty() { return name_kh; }
        public void setName_kh(String name_kh) { this.name_kh.set(name_kh); }

        @Column(name = "Stadium")
        @Type(type = "text")
        public String getStadium() { return stadium.get(); }
        @Transient
        public StringProperty stadiumProperty() { return stadium; }
        public void setStadium(String stadium) { this.stadium.set(stadium); }

        @Id
        @GeneratedValue(generator = "sqlite", strategy = GenerationType.AUTO)
        @Column(name = "ID_Krankheit", unique = true, nullable = false)
        public long getId() {
            return id_krankheit;
        }
        public void setId(long id_krankheit) {
            this.id_krankheit = id_krankheit;
        }

        @Override
        public String toString(){ return getName_kh() + " " + getStadium(); }
    }
    private long id_diagnose;
    private BooleanProperty gewissheit = new SimpleBooleanProperty();
    private BooleanProperty komplikation = new SimpleBooleanProperty(); // Осложнение

    @Access(AccessType.FIELD)
    @ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
    @JoinTable(name = "DIAGNOSE_KRANKHEIT", joinColumns = @JoinColumn(name = "ID_Diagnose", nullable = false), inverseJoinColumns = @JoinColumn(name = "ID_Krankheit"))
    private List<Krankheit> krankheiten = new ArrayList<>();
    @Access(AccessType.FIELD)
    @OneToMany(mappedBy = "diagnose", fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
    private Set<Empfang> empfangen = new HashSet<>();

    public Diagnose(boolean gewissheit, boolean komplikation, List<Krankheit> krankheiten)
    {
        this.gewissheit.set(gewissheit);
        this.komplikation.set(komplikation);
        this.krankheiten = krankheiten;
    }
    public Diagnose(long id_diagnose, boolean gewissheit, boolean komplikation, List<Krankheit> krankheiten)
    {
        this.gewissheit.set(gewissheit);
        this.komplikation.set(komplikation);
        this.krankheiten = krankheiten;
    }
    public Diagnose(){}

    @Column(name = "Gewissheit", nullable = false)
    @Type(type = "boolean")
    public boolean isGewissheit() { return gewissheit.get(); }
    @Transient
    public BooleanProperty gewissheitProperty() { return gewissheit; }
    public void setGewissheit(boolean gewissheit) { this.gewissheit.set(gewissheit); }

    @Column(name = "Komplikation")
    @Type(type = "boolean")
    public boolean isKomplikation() { return komplikation.get(); }
    @Transient
    public BooleanProperty komplikationProperty() { return komplikation; }
    public void setKomplikation(boolean komplikation) { this.komplikation.set(komplikation); }

    public List<Krankheit> getKrankheiten() { return krankheiten; }
    public void setKrankheiten(List<Krankheit> krankheiten) { this.krankheiten = krankheiten; }

    @Id
    @GeneratedValue(generator = "sqlite", strategy = GenerationType.AUTO)
    @Column(name = "ID_Diagnose", unique = true, nullable = false)
    public long getId() {
        return id_diagnose;
    }
    public void setId(long id_diagnose) {
        this.id_diagnose = id_diagnose;
    }

    @Override
    public String toString(){ return isGewissheit() + " " + isKomplikation(); }
}
