package modell;

import javafx.beans.property.*;
import javafx.collections.ObservableList;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Access(AccessType.PROPERTY)
@Table(name = "ADRESSE")
public class Adresse // Адрес
{
    private long id_adresse;
    private StringProperty gebiet = new SimpleStringProperty(); // Область
    private StringProperty bezirk = new SimpleStringProperty(); // Район
    private StringProperty siedlung = new SimpleStringProperty(); // Населенный пункт
    private StringProperty strasse = new SimpleStringProperty(); // Улица
    private StringProperty haus = new SimpleStringProperty(); // Дом
    private StringProperty eingang = new SimpleStringProperty(); // Подъезд
    private StringProperty wohnung = new SimpleStringProperty(); // Квартира

    @Access(AccessType.FIELD)
    @OneToOne(mappedBy = "adresse", fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
    private Korps korps;
    @Access(AccessType.FIELD)
    @OneToMany(mappedBy = "adresse", fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
    private Set<Kranke> kranken = new HashSet<>();

    public Adresse(String gebiet, String bezirk, String siedlung, String strasse, String haus, String eingang, String wohnung)
    {
        this.gebiet.set(gebiet);
        this.bezirk.set(bezirk);
        this.siedlung.set(siedlung);
        this.strasse.set(strasse);
        this.haus.set(haus);
        this.eingang.set(eingang);
        this.wohnung.set(wohnung);
    }
    public Adresse(long id_adresse, String gebiet, String bezirk, String siedlung, String strasse, String haus, String eingang, String wohnung, Korps korps)
    {
        this.gebiet.set(gebiet);
        this.bezirk.set(bezirk);
        this.siedlung.set(siedlung);
        this.strasse.set(strasse);
        this.haus.set(haus);
        this.eingang.set(eingang);
        this.wohnung.set(wohnung);
        this.korps = korps;
    }
    public Adresse(String gebiet, String bezirk, String siedlung, String strasse, String haus)
    {
        this.gebiet.set(gebiet);
        this.bezirk.set(bezirk);
        this.siedlung.set(siedlung);
        this.strasse.set(strasse);
        this.haus.set(haus);
    }
    public Adresse(){}

    @Column(name = "Gebiet", nullable = false)
    @Type(type = "text")
    public String getGebiet() { return gebiet.get(); }
    @Transient
    public StringProperty gebietProperty() { return gebiet; }
    public void setGebiet(String gebiet) { this.gebiet.set(gebiet); }

    @Column(name = "Bezirk")
    @Type(type = "text")
    public String getBezirk() { return bezirk.get(); }
    @Transient
    public StringProperty bezirkProperty() { return bezirk; }
    public void setBezirk(String bezirk) { this.bezirk.set(bezirk); }

    @Column(name = "Siedlung", nullable = false)
    @Type(type = "text")
    public String getSiedlung() { return siedlung.get(); }
    @Transient
    public StringProperty siedlungProperty() { return siedlung; }
    public void setSiedlung(String siedlung) { this.siedlung.set(siedlung); }

    @Column(name = "Strasse")
    @Type(type = "text")
    public String getStrasse() { return strasse.get(); }
    @Transient
    public StringProperty strasseProperty() { return strasse; }
    public void setStrasse(String strasse) { this.strasse.set(strasse); }

    @Column(name = "Haus", nullable = false)
    @Type(type = "text")
    public String getHaus() { return haus.get(); }
    @Transient
    public StringProperty hausProperty() { return haus; }
    public void setHaus(String haus) { this.haus.set(haus); }

    @Column(name = "Eingang")
    @Type(type = "text")
    public String getEingang() { return eingang.get(); }
    @Transient
    public StringProperty eingangProperty() { return eingang; }
    public void setEingang(String eingang) { this.eingang.set(eingang); }

    @Column(name = "Wohnung")
    @Type(type = "text")
    public String getWohnung() { return wohnung.get(); }
    @Transient
    public StringProperty wohnungProperty() { return wohnung; }
    public void setWohnung(String wohnung) { this.wohnung.set(wohnung); }

    public Korps getKorps() { return korps; }
    public void setKorps(Korps korps) { this.korps = korps; }

    @Id
    @GeneratedValue(generator = "sqlite", strategy = GenerationType.AUTO)
    @Column(name = "ID_Adresse", unique = true, nullable = false)
    public long getId() { return id_adresse; }
    public void setId(long id_adresse) {
        this.id_adresse = id_adresse;
    }

    @Override
    public String toString(){ return "Обл. " + getGebiet() + " р-он " + getBezirk() + " н.п. " + getSiedlung() + " ул. " + getStrasse() + " д. " + getHaus() + " под. " + getEingang() + " кв. " + getWohnung(); }
}

