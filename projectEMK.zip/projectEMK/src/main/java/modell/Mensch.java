package modell;

import javafx.beans.property.*;
import javafx.collections.ObservableList;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
@Access(AccessType.PROPERTY) // Доступ к атрибутам сущности PROPERTY - свойствам, FIELD - полям
public class Mensch
{
    protected long id;
    protected StringProperty nachname = new SimpleStringProperty();
    protected StringProperty vorname = new SimpleStringProperty();
    protected StringProperty zweiter_vorname = new SimpleStringProperty();
    protected StringProperty name = new SimpleStringProperty();

    @Access(AccessType.FIELD)
    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
    @JoinTable(name = "MENSCH_KOMMUNKATION", joinColumns = @JoinColumn(name = "ID_Mensch"), inverseJoinColumns = @JoinColumn(name = "ID_Kommunkation", nullable = false))
    protected Kommunkation kommunkation;

    public Mensch(String nachname, String vorname, String zweiter_vorname, Kommunkation kommunkation)
    {
        this.nachname.set(nachname);
        this.vorname.set(vorname);
        this.zweiter_vorname.set(zweiter_vorname);
        this.kommunkation = kommunkation;
        constructFullName();
    }
    public Mensch(long id, String nachname, String vorname, String zweiter_vorname, Kommunkation kommunkation)
    {
        this.nachname.set(nachname);
        this.vorname.set(vorname);
        this.zweiter_vorname.set(zweiter_vorname);
        this.kommunkation = kommunkation;
    }
    public Mensch(){}

    private void constructFullName(){ name.set(nachname.get() + " " + vorname.get() + " " + zweiter_vorname.get()); }

    @Column (name = "Nachname")
    @Type(type = "text")
    public String getNachname() { return nachname.get(); }
    @Transient
    public StringProperty nachnameProperty() { return nachname; }
    public void setNachname(String nachname)
    {
        this.nachname.set(nachname);
        constructFullName();
    }

    @Column (name = "Vorname", nullable = false)
    @Type(type = "text")
    public String getVorname() { return vorname.get(); }
    @Transient
    public StringProperty vornameProperty() { return vorname; }
    public void setVorname(String vorname)
    {
        this.vorname.set(vorname);
        constructFullName();
    }

    @Column (name = "Zweiter_vorname")
    @Type(type = "text")
    public String getZweiter_vorname() { return zweiter_vorname.get(); }
    @Transient
    public StringProperty zweiter_vornameProperty() { return zweiter_vorname; }
    public void setZweiter_vorname(String zweiter_vorname)
    {
        this.zweiter_vorname.set(zweiter_vorname);
        constructFullName();
    }

    public Kommunkation getKommunkation() { return kommunkation; }
    public void setKommunkation(Kommunkation kommunkation) { this.kommunkation = kommunkation; }

    @Transient
    public StringProperty getNamePropery(){
        return name;
    }

    @Id
    @GeneratedValue(generator = "sqlite", strategy = GenerationType.AUTO)
    @Column(name = "ID", nullable = false)
    public long getId() { return id; }
    public void setId(long id) {
        this.id = id;
    }

    @Override
    public String toString(){ return getNachname() + " " + getVorname() + " " + getZweiter_vorname(); }
}
