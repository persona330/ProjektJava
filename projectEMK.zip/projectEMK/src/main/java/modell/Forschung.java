package modell;

import javafx.beans.property.SimpleListProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.ObservableList;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Access(AccessType.PROPERTY)
@Table(name = "FORSCHUNG")
public class Forschung // Исследование
{
    public long id_forschung;

    private StringProperty datum_f = new SimpleStringProperty();
    private StringProperty form_f = new SimpleStringProperty();
    private StringProperty name_f = new SimpleStringProperty();

    @ManyToMany(mappedBy = "forschungen", fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
    private Set<Empfang> empfangen = new HashSet<>();

    public Forschung(String datum_f, String form_f, String name_f)
    {
        super();
        this.datum_f.set(datum_f);
        this.form_f.set(form_f);
        this.name_f.set(name_f);
    }
    public Forschung(int id, String datum_f, String form_f, String name_f)
    {
        this.datum_f.set(datum_f);
        this.form_f.set(form_f);
        this.name_f.set(name_f);
    }
    public Forschung(){}

    @Column (name = "Datum")
    @Type(type = "text")
    public String getDatum_f() { return datum_f.get(); }
    @Transient
    public StringProperty datum_fProperty() { return datum_f; }
    public void setDatum_f(String datum_f) { this.datum_f.set(datum_f); }

    @Column (name = "Form", nullable = false)
    @Type(type = "text")
    public String getForm_f() { return form_f.get(); }
    @Transient
    public StringProperty form_fProperty() { return form_f; }
    public void setForm_f(String form_f) { this.form_f.set(form_f); }

    @Column (name = "Name", nullable = false)
    @Type(type = "text")
    public String getName_f() { return name_f.get(); }
    @Transient
    public StringProperty name_fProperty() { return name_f; }
    public void setName_f(String name_f) { this.name_f.set(name_f); }

    @Id
    @GeneratedValue(generator = "sqliteForschung  ", strategy = GenerationType.AUTO)
    @Column (name = "ID_Forschung", nullable = false, unique = true)
    public long getId() { return id_forschung; }
    public void setId(long id_forschung) { this.id_forschung = id_forschung; }

    @Override
    public String toString(){ return getDatum_f() + " " + getForm_f() + " " + getName_f();}
    }
