package modell;

import javafx.beans.property.*;
import javafx.collections.ObservableList;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Access(AccessType.PROPERTY)
@Table(name = "KLINIK")
public class Klinik // Поликлиника
{
    private long id_klinik;
    private StringProperty name_k = new SimpleStringProperty();

    @Access(AccessType.FIELD)
    @OneToMany(mappedBy = "klinik", fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
    private Set<Korps> korpsen = new HashSet<>();
    @Access(AccessType.FIELD)
    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
    @JoinTable(name = "KLINIK_KOMMUNKATION", joinColumns = @JoinColumn(name = "ID_Klinik", nullable = false), inverseJoinColumns = @JoinColumn(name = "ID_Kommunkation"))
    private Kommunkation kommunkation;
    @Access(AccessType.FIELD)
    @OneToMany(mappedBy = "klinik", fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
    private List<Dokument> dokumenten = new ArrayList<>();

    public Klinik(String name_k, Set<Korps> korpsen, Kommunkation kommunkation,  List<Dokument> dokumenten)
    {
        this.name_k.set(name_k);
        this.korpsen = korpsen;
        this.kommunkation = kommunkation;
        this.dokumenten = dokumenten;
    }
    public Klinik(long id_klinik, String name_k, Set<Korps> korpsen, Kommunkation kommunkation,  List<Dokument> dokumenten)
    {
        this.name_k.set(name_k);
        this.korpsen = korpsen;
        this.kommunkation = kommunkation;
        this.dokumenten = dokumenten;
    }
    public Klinik(){}

    @Column(name = "Name", nullable = false)
    @Type(type = "text")
    public String getName_k() { return name_k.get(); }
    @Transient
    public StringProperty name_kProperty() { return name_k; }
    public void setName_k(String name_k) { this.name_k.set(name_k); }

    public Set<Korps> getKorpsen() { return korpsen; }
    public void setKorpsen(Set<Korps> korpsen) { this.korpsen = korpsen; }

    public Kommunkation getKommunkation() { return kommunkation; }
    public void setKommunkation(Kommunkation kommunkation) { this.kommunkation = kommunkation; }

    public List<Dokument> getDokumenten() { return dokumenten; }
    public void setDokumenten(List<Dokument> dokumenten) { this.dokumenten = dokumenten; }

    @Id
    @GeneratedValue(generator = "sqliteKlinik", strategy = GenerationType.AUTO)
    @Column(name = "ID_Klinik", unique = true, nullable = false)
    public long getId() { return id_klinik; }
    public void setId(long id_klinik) {
        this.id_klinik = id_klinik;
    }

    @Override
    public String toString(){ return getName_k();}
    }
