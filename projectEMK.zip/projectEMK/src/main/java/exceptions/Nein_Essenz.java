package exceptions;

public class Nein_Essenz extends Exception // Выдает ошибку
{ public Nein_Essenz(String message){
        super(message);
    }}
