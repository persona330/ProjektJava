package controller;

import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.util.Callback;
import main.Main;
import modell.*;
import registry.Registrieren;
import schleuse.Empfang_Schleuse;
import schleuse.Schleuse;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.util.Date;


public class Menschen_Controller
{
    @FXML
    private TableView<Kranke> krankeTable;
    @FXML
    private TableColumn<Kranke, String> nameColumn;
    @FXML
    private TableColumn<Kranke, String> geschlechtColumn;
    @FXML
    private TableColumn<Kranke, Date> geburtsdatumColumn;
    @FXML
    private TableColumn<Kranke, Number> alterColumn;
    @FXML
    private TableColumn<Kranke, Adresse> wohnortColumn;
    @FXML
    private TableColumn<Kranke, Dokument> dokumentColumn;
    @FXML
    private TableColumn<Kranke, Kommunkation> kommunkationColumn;

    @FXML
    private TableView<Arzt> arztTable;
    @FXML
    private TableColumn<Arzt, String> name_arColumn;
    @FXML
    private TableColumn<Arzt, Arzt.Spezialisierung> spezialisierungColumn;
    @FXML
    private TableColumn<Arzt, Arzt.Dienststelle> dienststelleColumn;
    @FXML
    private TableColumn<Arzt, Arzt.Regal> regalColumn;
    @FXML
    private TableColumn<Arzt, Kommunkation> kommunkation_arColumn;

    @FXML
    private TableView<Empfang> empfangTable;
    @FXML
    private TableColumn<Empfang, String> zeit_aColumn;
    @FXML
    private TableColumn<Empfang, String> datum_aColumn;
    @FXML
    private TableColumn<Empfang, Diagnose.Krankheit> krankheitColunm;
    @FXML
    private TableColumn<Empfang, Behandlung> behandlungColumn;
    @FXML
    private TableColumn<Empfang, Forschung> forschungColumn;

    @FXML
    private TableView<Klinik> klinikTable;
    @FXML
    private TableColumn<Klinik, String> name_kColumn;
    @FXML
    private TableColumn<Klinik, Korps> korpsColumn;
    @FXML
    private TableColumn<Klinik, Korps.Abteil> abteilColumn;
    @FXML
    private TableColumn<Klinik, Korps.Arbeitszimmer> arbeitszimmerColumn;
    @FXML
    private TableColumn<Klinik, Adresse> adresseKlColumn;
    @FXML
    private TableColumn<Klinik, Dokument> dokumentKlColumn;

    private Schleuse<Kranke> kranke_schleuse = Registrieren.getInstance().getKranke_schleuse();
    private Schleuse<Arzt> arzt_schleuse = Registrieren.getInstance().getArzt_schleuse();
    private Schleuse<Empfang> empfang_schleuse = Registrieren.getInstance().getEmpfang_schleuse();
    private Schleuse<Klinik> klinik_schleuse = Registrieren.getInstance().getKlinik_schleuse();

    private ObservableList<Kranke> kranken = FXCollections.observableArrayList(kranke_schleuse.all());
    private ObservableList<Arzt> arzten = FXCollections.observableArrayList(arzt_schleuse.all());
    private ObservableList<Empfang> empfangen = FXCollections.observableArrayList(empfang_schleuse.all());
    private ObservableList<Klinik> kliniken = FXCollections.observableArrayList(klinik_schleuse.all());

    private Main app;
    public void setMain(Main app){
        this.app = app;
    }

    @FXML
    public void initialize()
    {
        nameColumn.setCellValueFactory(cellDate -> cellDate.getValue().getNamePropery());
        geschlechtColumn.setCellValueFactory(cellDate -> cellDate.getValue().geschlechtProperty());
        geburtsdatumColumn.setCellValueFactory(cellDate -> cellDate.getValue().geburtsdatumProperty());
        alterColumn.setCellValueFactory(cellDate -> cellDate.getValue().alterProperty());
        wohnortColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Kranke, Adresse>, ObservableValue<Adresse>>(){
            public ObservableValue<Adresse> call(TableColumn.CellDataFeatures<Kranke, Adresse> p){
                return new ReadOnlyObjectWrapper<>(p.getValue().getAdresse());
            }
        });
        dokumentColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Kranke, Dokument>, ObservableValue<Dokument>>(){
            public ObservableValue<Dokument> call(TableColumn.CellDataFeatures<Kranke, Dokument> p){
                return new ReadOnlyObjectWrapper<>(p.getValue().getDokument());
            }
        });
        kommunkationColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Kranke, Kommunkation>, ObservableValue<Kommunkation>>(){
            public ObservableValue<Kommunkation> call(TableColumn.CellDataFeatures<Kranke, Kommunkation> p){
                return new ReadOnlyObjectWrapper<>(p.getValue().getKommunkation());
            }
        });
        krankeTable.setItems(kranken);

        name_arColumn.setCellValueFactory(cellDate -> cellDate.getValue().getNamePropery());
        dienststelleColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Arzt, Arzt.Dienststelle>, ObservableValue<Arzt.Dienststelle>>(){
            public ObservableValue<Arzt.Dienststelle> call(TableColumn.CellDataFeatures<Arzt, Arzt.Dienststelle> p){
                return new ReadOnlyObjectWrapper<>(p.getValue().getDienststelle());
            }
        });
        kommunkation_arColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Arzt, Kommunkation>, ObservableValue<Kommunkation>>(){
            public ObservableValue<Kommunkation> call(TableColumn.CellDataFeatures<Arzt, Kommunkation> p){
                return new ReadOnlyObjectWrapper<>(p.getValue().getKommunkation());
            }
        });
        arztTable.setItems(arzten);

        datum_aColumn.setCellValueFactory(cellDate -> cellDate.getValue().datum_eProperty());
        zeit_aColumn.setCellValueFactory(cellDate -> cellDate.getValue().zeit_eProperty());
        empfangTable.setItems(empfangen);

        name_kColumn.setCellValueFactory(cellDate -> cellDate.getValue().name_kProperty());
        /*adresseKlColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Klinik, Adresse>, ObservableValue<Adresse>>(){
            public ObservableValue<Adresse> call(TableColumn.CellDataFeatures<Klinik, Adresse> p){
                return new ReadOnlyObjectWrapper<>(p.getValue().getKorpsen().getAdresse());
            }
        });
        */
        klinikTable.setItems(kliniken);
    }

    public void neueKarte()
    {
        Kranke kranke = new Kranke();
        Arzt arzt = new Arzt();
        Adresse adresse = new Adresse();
        Kommunkation kommunkation = new Kommunkation();
        Dokument dokument = new Dokument();
        Empfang empfang = new Empfang();
        Diagnose diagnose = new Diagnose();
        Diagnose.Krankheit krankheit = new Diagnose.Krankheit();
        Behandlung behandlung = new Behandlung();
        Forschung forschung = new Forschung();
        Klinik klinik = new Klinik();
        Korps korps = new Korps();
        Korps.Arbeitszimmer arbeitszimmer = new Korps.Arbeitszimmer();
        Korps.Abteil abteil = new Korps.Abteil();
        app.openDialog(kranke, arzt, adresse, kommunkation, dokument, empfang, diagnose, krankheit, behandlung, forschung, klinik, korps, arbeitszimmer, abteil);
        kranken.add(kranke);
        arzten.add(arzt);
        empfangen.add(empfang);
        kliniken.add(klinik);
    }

    public void editMensch()
    {
        Kranke kranke = krankeTable.getSelectionModel().getSelectedItem();
        Arzt arzt = arztTable.getSelectionModel().getSelectedItem();
        Empfang empfang = empfangTable.getSelectionModel().getSelectedItem();
        Klinik klinik = klinikTable.getSelectionModel().getSelectedItem();
        Adresse adresse = new Adresse();
        Kommunkation kommunkation = new Kommunkation();
        Dokument dokument = new Dokument();
        Diagnose diagnose = new Diagnose();
        Diagnose.Krankheit krankheit = new Diagnose.Krankheit();
        Behandlung behandlung = new Behandlung();
        Forschung forschung = new Forschung();
        Korps korps = new Korps();
        Korps.Arbeitszimmer arbeitszimmer = new Korps.Arbeitszimmer();
        Korps.Abteil abteil = new Korps.Abteil();
        if (kranken != null && arzten != null && empfangen != null && kliniken != null)
            app.openDialog(kranke, arzt, adresse, kommunkation, dokument, empfang, diagnose, krankheit, behandlung, forschung, klinik, korps, arbeitszimmer, abteil);
    }

    public void deleteMensch()
    {
        int index = krankeTable.getSelectionModel().getSelectedIndex();
        int index1 = arztTable.getSelectionModel().getSelectedIndex();
        int index2 = empfangTable.getSelectionModel().getSelectedIndex();
        int index3 = klinikTable.getSelectionModel().getSelectedIndex();
        if (index != -1 && index1 != -1 && index2 != -1 && index3 != -1)
        {
            kranke_schleuse.delete(kranken.get(index));
            kranken.remove(index);
            arzt_schleuse.delete(arzten.get(index1));
            arzten.remove(index1);
            empfang_schleuse.delete(empfangen.get(index2));
            empfangen.remove(index2);
            klinik_schleuse.delete(kliniken.get(index3));
            kliniken.remove(index3);
        }

    }
}
