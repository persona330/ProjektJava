package controller;

import javafx.beans.property.SimpleListProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import modell.*;
import registry.Registrieren;
import schleuse.*;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class Mensch_Controller
{

    @FXML
    private TextField NachnameKTF; // Фамилия
    @FXML
    private TextField VornameKTF; // Имя
    @FXML
    private TextField Zweiter_vornameKTF; // Отчество
    @FXML
    private TextField GeburtsdatumTF; // Дата рождения
    @FXML
    private Spinner<Integer> AlterS; // Возростт
    private ObservableValue<Integer> alterInt = new SimpleObjectProperty<>();
    @FXML
    private CheckBox CheckM = new CheckBox("Мужской"); // Мужской
    @FXML
    private CheckBox CheckW = new CheckBox("Женский"); // Женский
    @FXML
    private TextField GebietKrTF; // Область
    @FXML
    private TextField BezirkKrTF; // Район
    @FXML
    private TextField SiedlungKrTF; // Населенныц пункт
    @FXML
    private TextField StrasseKrTF; // Улица
    @FXML
    private TextField HausKrTF; // Дом
    @FXML
    private TextField EingangKrTF; // Подъезд
    @FXML
    private TextField WohnungKrTF; // Квартира
    @FXML
    private TextField E_mailKrTF;
    @FXML
    private TextField TelefonKrTF;
    @FXML
    private ComboBox<String> Name_dKrCB;
    @FXML
    private TextField Ausgestellt_vonKrTF;
    @FXML
    private TextField SerieKrTF;
    @FXML
    private TextField Nummer_dKrTF;
    @FXML
    private TextField Datum_ausstellungKrTF;

    // Arzt
    @FXML
    private TextField NachnameATF;
    @FXML
    private TextField VornameATF;
    @FXML
    private TextField Zweiter_vornameATF;
    @FXML
    private ComboBox<Arzt.Dienststelle> DienststelleCB;
    @FXML
    private ComboBox<Arzt.Regal> RegalCB;
    @FXML
    private ListView<Arzt.Regal> RegalLV;
    private ObservableList<Arzt.Regal> regalen = new SimpleListProperty<Arzt.Regal>();
    @FXML
    private ComboBox<Arzt.Spezialisierung> SpezialisierungCB;
    @FXML
    private ListView<Arzt.Spezialisierung> SpezialisierungLV;
    private ObservableList<Arzt.Spezialisierung> spezialisierungen = new SimpleListProperty<>();
    @FXML
    private TextField E_mailArTF;
    @FXML
    private TextField TelefonArTF;

    // Empfang
    @FXML
    private TextField Zeit_aTF;
    @FXML
    private TextField Datum_aTF;
    @FXML
    private ComboBox<String> KrankheitCB;
    @FXML
    private ComboBox<String> StadiumCB;
    @FXML
    private CheckBox KomplikationCB;
    @FXML
    private TableView<Diagnose.Krankheit> KrankheitTable;
    private ObservableList<Diagnose.Krankheit> krankheiten = FXCollections.observableArrayList();
    @FXML
    private TableColumn<Diagnose.Krankheit, String> KrankheitColumn;
    @FXML
    private TableColumn<Diagnose.Krankheit, String> StadiumColumn;
    @FXML
    private TextField StartdatumTF;
    @FXML
    private TextField EnddatumTF;
    @FXML
    private ComboBox<String> Name_bCB;
    @FXML
    private ComboBox<String> Form_bCB;
    @FXML
    private ComboBox<String> MethodeCB;
    @FXML
    private TextField DosisTF;
    @FXML
    private TableView<Behandlung> BehandlungTable;
    private ObservableList<Behandlung> behandlungen = FXCollections.observableArrayList();
    @FXML
    private TableColumn<Behandlung, String> Name_bColumn;
    @FXML
    private TableColumn<Behandlung, String> Form_bColumn;
    @FXML
    private TableColumn<Behandlung, String> MethodeColumn;
    @FXML
    private TableColumn<Behandlung, String> DosisColumn;
    @FXML
    private TableColumn<Behandlung, String> StartdatumColumn;
    @FXML
    private TableColumn<Behandlung, String> EnddatumColumn;
    @FXML
    private ComboBox<String> Name_fCB;
    @FXML
    private ComboBox<String> Form_fCB;
    @FXML
    private TextField Datum_fTF;
    @FXML
    private TableView<Forschung> ForschungTable;
    private ObservableList<Forschung> forschungen = FXCollections.observableArrayList();
    @FXML
    private TableColumn<Forschung, String> Name_fColumn;
    @FXML
    private TableColumn<Forschung, String> Form_fColumn;
    @FXML
    private TableColumn<Forschung, String> Datum_fColumn;

    //Klinik
    @FXML
    private TextField Name_kTF;
    @FXML
    private ComboBox<String> AbteilCB;
    @FXML
    private TextField KorpsTF;
    @FXML
    private TextField ArbetszimmerTF;
    @FXML
    private TextField GebietKlTF;
    @FXML
    private TextField BezirkKlTF;
    @FXML
    private TextField SiedlungKlTF;
    @FXML
    private TextField StrasseKlTF;
    @FXML
    private TextField HausKlTF;
    @FXML
    private TextField E_mailKlTF;
    @FXML
    private TextField TelefonKlTF;
    @FXML
    private ComboBox<String> Name_dKlCB;
    @FXML
    private TextField Ausgestellt_vonKlTF;
    @FXML
    private TextField SerieKlTF;
    @FXML
    private TextField Nummer_dKlTF;
    @FXML
    private TextField Datum_ausstellungKlTF;
    @FXML
    private TableView<Dokument> DokumentKlTable;
    private ObservableList<Dokument> dokumenten = FXCollections.observableArrayList();
    @FXML
    private TableColumn<Dokument, String> Name_dKlColumn;
    @FXML
    private TableColumn<Dokument, String> Ausgestellt_vonKlColumn;
    @FXML
    private TableColumn<Dokument, Number> SerieKlColumn;
    @FXML
    private TableColumn<Dokument, Number> Nummer_dKlColumn;
    @FXML
    private TableColumn<Dokument, String> Datum_ausstellungKlColumn;

    private Schleuse<Kranke> kranke_schleuse = Registrieren.getInstance().getKranke_schleuse();
    private Schleuse<Arzt> arzt_schleuse = Registrieren.getInstance().getArzt_schleuse();
    private Schleuse<Arzt.Regal> regal_schleuse = Registrieren.getInstance().getRegal_schleuse();
    private Schleuse<Arzt.Spezialisierung> spezialisierung_schleuse = Registrieren.getInstance().getSpezialisierung_schleuse();
    private Schleuse<Arzt.Dienststelle> dienststelle_schleuse = Registrieren.getInstance().getDienststelle_schleuse();
    private Schleuse<Empfang> empfang_schleuse = Registrieren.getInstance().getEmpfang_schleuse();
    private Schleuse<Klinik> klinik_schleuse = Registrieren.getInstance().getKlinik_schleuse();

    private Kranke kranke;
    private Arzt arzt;
    private Empfang empfang;
    private Klinik klinik;

    public void InsertKr()
    {
        String krankheitCBValue = KrankheitCB.getValue();
        String stadiumCBValue = StadiumCB.getValue();
        Diagnose.Krankheit addKrankheit = new Diagnose.Krankheit(krankheitCBValue, stadiumCBValue);
        if(addKrankheit != null)krankheiten.add(addKrankheit);
    }
    public void DeleteKr()
    {
        Diagnose.Krankheit delKrankheit = KrankheitTable.getSelectionModel().getSelectedItem();
        krankheiten.remove(delKrankheit);
    }

    public void InsertBe()
    {
        String name_bCBValue = Name_bCB.getValue();
        String form_bCBValue = Form_bCB.getValue();
        String methodeCBValue = MethodeCB.getValue();
        String dosisTFText = DosisTF.getText();
        String startdatumTFText = StartdatumTF.getText();
        String enddatumTFText = EnddatumTF.getText();
        Behandlung addBehandlung = new Behandlung(startdatumTFText, enddatumTFText, methodeCBValue, form_bCBValue, name_bCBValue, dosisTFText);
        if(addBehandlung != null) behandlungen.add(addBehandlung);
    }
    public void DeleteBe()
    {
        Behandlung delBehandlung = BehandlungTable.getSelectionModel().getSelectedItem();
        behandlungen.remove(delBehandlung);
    }

    public void InsertFo()
    {
        String name_fCBValue = Name_fCB.getValue();
        String form_fCBValue = Form_fCB.getValue();
        String datum_fTFText = Datum_fTF.getText();
        Forschung addForschung = new Forschung(datum_fTFText, form_fCBValue, name_fCBValue);
        if(addForschung != null) forschungen.add(addForschung);
    }
    public void DeleteFo()
    {
        Forschung delForschung = ForschungTable.getSelectionModel().getSelectedItem();
        forschungen.remove(delForschung);
    }

    @FXML
    protected void initialize()
    {
        AlterS.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 200, 18));
        RegalCB.setItems(FXCollections.observableArrayList(regal_schleuse.all()));
        SpezialisierungCB.setItems(FXCollections.observableArrayList(spezialisierung_schleuse.all()));
        Name_dKrCB.setItems(FXCollections.observableArrayList("Паспорт", "Полис", "ИНН"));
        DienststelleCB.setItems(FXCollections.observableArrayList(dienststelle_schleuse.all()));
        KrankheitCB.setItems(FXCollections.observableArrayList("Covid_19", "Пневмания", "Ангина", "ОРВИ"));
        StadiumCB.setItems(FXCollections.observableArrayList("Первая стадия", "Вторая стадия", "Третья стадия", "Четвертая стадия"));
        Name_bCB.setItems(FXCollections.observableArrayList("Парацетамол"));
        Form_bCB.setItems(FXCollections.observableArrayList("Твердая", "Жидкая"));
        MethodeCB.setItems(FXCollections.observableArrayList("Фармакотерапия", "Фитотерапия", "Иммунотерапия", "Радиотерапия", "УВЧ-терапия", "Магнитотерапия", "Лекарственный электрофорез", "Лазеротерапия", "Хирургическое лечение"));
        Name_fCB.setItems(FXCollections.observableArrayList(""));
        Form_fCB.setItems(FXCollections.observableArrayList(""));
        AbteilCB.setItems(FXCollections.observableArrayList(""));
        Name_dKlCB.setItems(FXCollections.observableArrayList("ИНН"));
        InsertKr();
        KrankheitColumn.setCellValueFactory(cellDate -> cellDate.getValue().name_khProperty());
        StadiumColumn.setCellValueFactory(cellDate -> cellDate.getValue().stadiumProperty());
        KrankheitTable.setItems(krankheiten);
        InsertBe();
        Name_bColumn.setCellValueFactory(cellDate -> cellDate.getValue().name_bProperty());
        Form_bColumn.setCellValueFactory(cellDate -> cellDate.getValue().form_bProperty());
        MethodeColumn.setCellValueFactory(cellDate -> cellDate.getValue().methodeProperty());
        DosisColumn.setCellValueFactory(cellDate -> cellDate.getValue().dosisProperty());
        StartdatumColumn.setCellValueFactory(cellDate -> cellDate.getValue().startdatumProperty());
        EnddatumColumn.setCellValueFactory(cellDate -> cellDate.getValue().enddatumProperty());
        BehandlungTable.setItems(behandlungen);
        InsertFo();
        Name_fColumn.setCellValueFactory(cellDate -> cellDate.getValue().name_fProperty());
        Form_fColumn.setCellValueFactory(cellDate -> cellDate.getValue().form_fProperty());
        Datum_fColumn.setCellValueFactory(cellDate -> cellDate.getValue().datum_fProperty());
        ForschungTable.setItems(forschungen);
        //InsertDo();
        //Name_dKlColumn.setCellValueFactory(cellDate -> cellDate.getValue().name_dProperty());
        //Nummer_dKlColumn.setCellValueFactory(cellDate -> cellDate.getValue().nummer_dProperty());
        //SerieKlColumn.setCellValueFactory(cellDate -> cellDate.getValue().serieProperty());
        //Ausgestellt_vonKlColumn.setCellValueFactory(cellDate -> cellDate.getValue().ausgestellt_vonProperty());
        //Datum_ausstellungKlColumn.setCellValueFactory(cellDate -> cellDate.getValue().datum_ausstellungProperty());
        //DokumentKlTable.setItems(dokumenten);
    }

    public void setMensch(Kranke kranke, Arzt arzt, Adresse adresse, Kommunkation kommunkation, Dokument dokument, Empfang empfang, Diagnose diagnose, Diagnose.Krankheit krankheit, Behandlung behandlung, Forschung forschung, Klinik klinik, Korps korps, Korps.Arbeitszimmer arbeitszimmer, Korps.Abteil abteil)
    {
        this.kranke = kranke;
        NachnameKTF.setText(kranke.getNachname());
        VornameKTF.setText(kranke.getVorname());
        Zweiter_vornameKTF.setText(kranke.getZweiter_vorname());
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        if (kranke.getGeburtsdatum() != null){
            GeburtsdatumTF.setText(dateFormat.format(kranke.getGeburtsdatum()));
        }
        AlterS.getValueFactory().setValue(kranke.getAlter());
        GebietKrTF.setText(adresse.getGebiet());
        BezirkKrTF.setText(adresse.getBezirk());
        SiedlungKrTF.setText(adresse.getSiedlung());
        StrasseKrTF.setText(adresse.getStrasse());
        HausKrTF.setText(adresse.getHaus());
        EingangKrTF.setText(adresse.getEingang());
        WohnungKrTF.setText(adresse.getWohnung());
        E_mailKrTF.setText(kommunkation.getE_mail());
        TelefonKrTF.setText(Integer.toString(kommunkation.getTelefon()));
        Name_dKrCB.setValue(dokument.getName_d());
        Ausgestellt_vonKrTF.setText(dokument.getAusgestellt_von());
        SerieKrTF.setText(Integer.toString(dokument.getSerie()));
        Nummer_dKrTF.setText(Integer.toString(dokument.getNummer_d()));
        Datum_ausstellungKrTF.setText(dokument.getDatum_ausstellung());

        this.arzt = arzt;
        NachnameATF.setText(arzt.getNachname());
        VornameATF.setText(arzt.getVorname());
        Zweiter_vornameATF.setText(arzt.getZweiter_vorname());
        DienststelleCB.setValue(arzt.getDienststelle());
        regalen = FXCollections.observableArrayList(arzt.getRegalen());
        RegalLV.setItems(regalen);
        spezialisierungen = FXCollections.observableArrayList(arzt.getSpezialisierungen());
        SpezialisierungLV.setItems(spezialisierungen);
        E_mailArTF.setText(kommunkation.getE_mail());
        TelefonArTF.setText(Integer.toString(kommunkation.getTelefon()));

        this.empfang = empfang;
        Datum_aTF.setText(empfang.getDatum_e());
        Zeit_aTF.setText(empfang.getZeit_e());
        KrankheitCB.setValue(krankheit.getName_kh());
        StadiumCB.setValue(krankheit.getStadium());
        StartdatumTF.setText(behandlung.getStartdatum());
        EnddatumTF.setText(behandlung.getEnddatum());
        Name_bCB.setValue(behandlung.getName_b());
        Form_bCB.setValue(behandlung.getForm_b());
        MethodeCB.setValue(behandlung.getMethode());
        DosisTF.setText(behandlung.getDosis());
        Name_fCB.setValue(forschung.getName_f());
        Form_fCB.setValue(forschung.getForm_f());
        Datum_fTF.setText(forschung.getDatum_f());

        this.klinik = klinik;
        Name_kTF.setText(klinik.getName_k());
        KorpsTF.setText(korps.getNummer_ko());
        AbteilCB.setValue(abteil.getName_ab());
        ArbetszimmerTF.setText(arbeitszimmer.getNummer_arb());
        GebietKlTF.setText(adresse.getGebiet());
        BezirkKlTF.setText(adresse.getBezirk());
        SiedlungKlTF.setText(adresse.getSiedlung());
        StrasseKlTF.setText(adresse.getStrasse());
        HausKlTF.setText(adresse.getHaus());
        E_mailKlTF.setText(kommunkation.getE_mail());
        TelefonKlTF.setText(Integer.toString(kommunkation.getTelefon()));
    }

    public void addRegal()
    {
        Arzt.Regal addRegal = RegalCB.getValue();
        if (addRegal != null && !regalen.contains(addRegal)){ regalen.add(addRegal); }
    }

    public void delRegal()
    {
        Arzt.Regal delRegal = RegalCB.getSelectionModel().getSelectedItem();
        if (delRegal != null){ regalen.remove(delRegal); }
    }

    public void addSpezialisierung()
    {
        Arzt.Spezialisierung addSpezialisierung = SpezialisierungCB.getValue();
        if (addSpezialisierung != null && !spezialisierungen.contains(addSpezialisierung)){ spezialisierungen.add(addSpezialisierung); }
    }
    public void delSpezialisierung()
    {
        Arzt.Spezialisierung delSpezialisierung = SpezialisierungCB.getSelectionModel().getSelectedItem();
        if (delSpezialisierung != null){ spezialisierungen.remove(delSpezialisierung); }
    }

    public void DatumFormat() { DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd"); }

    public void clickSave() throws ParseException
    {
        String nachnameKTFText = NachnameKTF.getText();
        String vornameKTFText = VornameKTF.getText();
        String zweiter_vornameKTFText = Zweiter_vornameKTF.getText();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date geburtsdatumTFText = dateFormat.parse(GeburtsdatumTF.getText());

        Date date = new Date();
        String datum = String.format("%tF", date);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String datumG = GeburtsdatumTF.getText();
        LocalDate startDate = LocalDate.parse(datumG, formatter);
        LocalDate endDate = LocalDate.parse(datum, formatter);
        Period period = Period.between(startDate, endDate);
        int alter = period.getYears();

        String gebietKrTFText = GebietKrTF.getText();
        String bezirkKrTFText = BezirkKrTF.getText();
        String siedlungKrTFText = SiedlungKrTF.getText();
        String strasseKrTFText= StrasseKrTF.getText();
        String hausKrTFText = HausKrTF.getText();
        String eingangKrTFText = EingangKrTF.getText();
        String wohnungKrTFText = WohnungKrTF.getText();
        String e_mailKrTFText = E_mailKrTF.getText();
        int telefonKrTFLong = Integer.parseInt(TelefonKrTF.getText());
        String name_dKrCBText = Name_dKrCB.getValue();
        String ausgestellt_vonKrTFText = Ausgestellt_vonKrTF.getText();
        int serieKrTFTnt = Integer.parseInt(SerieKrTF.getText());
        int nummer_dKrTFTnt = Integer.parseInt(Nummer_dKrTF.getText());
        String datum_ausstellungKrTFText = Datum_ausstellungKrTF.getText();

        String nachnameATFText = NachnameATF.getText();
        String vornameATFText = VornameATF.getText();
        String zweiter_vornameATFText = Zweiter_vornameATF.getText();
        Arzt.Dienststelle dienststelleCBText = DienststelleCB.getValue();
        int telefonArTFLong = Integer.parseInt(TelefonArTF.getText());
        String e_mailArTFText = E_mailArTF.getText();

        String datum_aTFText = Datum_aTF.getText();
        String zeit_aTFText = Zeit_aTF.getText();

        String name_kTFText = Name_kTF.getText();
        String korpsTFText = KorpsTF.getText();
        String abteilCBValue = AbteilCB.getValue();
        String arbetszimmerTFText = ArbetszimmerTF.getText();
        String gebietKlTFText = GebietKrTF.getText();
        String bezirkKlTFText = BezirkKrTF.getText();
        String siedlungKlTFText = SiedlungKrTF.getText();
        String strasseKlTFText= StrasseKrTF.getText();
        String hausKlTFText = HausKlTF.getText();
        String e_mailKlTFText = E_mailKrTF.getText();
        int telefonKlTFLong = Integer.parseInt(TelefonKrTF.getText());
        String name_dKlCBText = Name_dKrCB.getValue();
        String ausgestellt_vonKlTFText = Ausgestellt_vonKrTF.getText();
        int serieKlTFTnt = Integer.parseInt(SerieKrTF.getText());
        int nummer_dKlTFTnt = Integer.parseInt(Nummer_dKrTF.getText());
        String datum_ausstellungKlTFText = Datum_ausstellungKrTF.getText();

        Adresse adresseKr = new Adresse(gebietKrTFText, bezirkKrTFText, siedlungKrTFText, strasseKrTFText, hausKrTFText, eingangKrTFText, wohnungKrTFText);
        Adresse adresseKl = new Adresse(gebietKlTFText, bezirkKlTFText, siedlungKlTFText, strasseKlTFText, hausKlTFText);
        Kommunkation kommunkationKr = new Kommunkation(e_mailKrTFText, telefonKrTFLong);
        Kommunkation kommunkationAr = new Kommunkation(e_mailArTFText, telefonArTFLong);
        Kommunkation kommunkationKl = new Kommunkation(e_mailKlTFText, telefonKlTFLong);
        Dokument dokument = new Dokument(name_dKrCBText, serieKrTFTnt, nummer_dKrTFTnt, ausgestellt_vonKrTFText, datum_ausstellungKrTFText);
        //Korps korps = new Korps();
        //korps.setNummer_ko(korpsTFText);
        //korps.setAbteil()

        Diagnose diagnose = new Diagnose();
        if (KomplikationCB.isSelected()){diagnose.setKomplikation(true);}
        else{diagnose.setKomplikation(false);}

        kranke.setNachname(nachnameKTFText);
        kranke.setVorname(vornameKTFText);
        kranke.setZweiter_vorname(zweiter_vornameKTFText);
        kranke.setGeburtsdatum(geburtsdatumTFText);
        //kranke.setAlter(AlterS.getValue());
        kranke.setAlter(alter);
        if (CheckM.isSelected()){kranke.setGeschlecht("Мужской");}
        if (CheckW.isSelected()) {kranke.setGeschlecht("Женский");}
        kranke.setAdresse(adresseKr);
        kranke.setKommunkation(kommunkationKr);
        kranke.setDokument(dokument);

        arzt.setNachname(nachnameATFText);
        arzt.setVorname(vornameATFText);
        arzt.setZweiter_vorname(zweiter_vornameATFText);
        arzt.setRegalen(regalen);
        arzt.setSpezialisierungen(spezialisierungen);
        arzt.setDienststelle(dienststelleCBText);
        arzt.setKommunkation(kommunkationAr);

        empfang.setDatum_e(datum_aTFText);
        empfang.setZeit_e(zeit_aTFText);
        empfang.setDiagnose(diagnose);
        diagnose.setKrankheiten(krankheiten);
        empfang.setBehandlungen(behandlungen);
        empfang.setForschungen(forschungen);

        klinik.setName_k(name_kTFText);
        //klinik.setDokumenten(dokumenten);

        try
        {
            if (kranke.getId() != 0) kranke_schleuse.update(kranke);
            else kranke_schleuse.insert(kranke);

            if (arzt.getId() != 0) { arzt_schleuse.update(arzt); }
            else arzt_schleuse.insert(arzt);

            if(empfang.getId() != 0) empfang_schleuse.update(empfang);
            else empfang_schleuse.insert(empfang);

            if(klinik.getId() != 0) klinik_schleuse.update(klinik);
            else klinik_schleuse.insert(klinik);

            Stage stage = (Stage) NachnameKTF.getScene().getWindow();
            stage.close();
        }
        catch (Exception e)
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Ошибка");
            alert.setHeaderText(e.getMessage());
            alert.showAndWait();
        }
    }
    public void clickCancel()
    {
        Stage stage = (Stage) NachnameKTF.getScene().getWindow();
        stage.close();
    }
    public void clickBut()
    {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Информация");
        alert.setHeaderText("Формат даты: yyyy-mm-dd");
        alert.setContentText("Прозьба выполнять!");
        alert.showAndWait();
    }
    public void clickCheck()
    {
        if (CheckM.isSelected()){CheckW.setIndeterminate(true); CheckM.setSelected(true);}
        if (CheckW.isSelected()) {CheckM.setIndeterminate(true); CheckW.setSelected(true);}
    }
}
