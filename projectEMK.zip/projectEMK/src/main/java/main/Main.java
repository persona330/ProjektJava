package main;

import controller.Mensch_Controller;
import controller.Menschen_Controller;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import modell.*;

import java.io.IOException;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception
    {
        FXMLLoader loader = new FXMLLoader(); // Создание стартовое окно
        loader.setLocation(getClass().getResource("../views/Mensch_anzeigen.fxml"));

        BorderPane root = (BorderPane)loader.load();
        primaryStage.setScene(new Scene(root));
        primaryStage.setTitle("Все люди");

        Menschen_Controller controlleren = loader.getController();
        controlleren.setMain(this);
        primaryStage.show();//dialog.showAndWait()
    }
    public void openDialog(Kranke kranke, Arzt arzt, Adresse adresse, Kommunkation kommunkation, Dokument dokument, Empfang empfang, Diagnose diagnose, Diagnose.Krankheit krankheit, Behandlung behandlung, Forschung forschung, Klinik klinik, Korps korps, Korps.Arbeitszimmer arbeitszimmer, Korps.Abteil abteil) {
        try
        {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("../views/EMK.fxml"));
            VBox root = (VBox) loader.load();
            Stage dialog = new Stage();
            dialog.setScene(new Scene(root));
            dialog.setTitle("Электронная медицинская карта");
            dialog.initModality(Modality.WINDOW_MODAL);

            Mensch_Controller controller = loader.getController();
            controller.setMensch(kranke, arzt, adresse, kommunkation, dokument, empfang, diagnose, krankheit, behandlung, forschung, klinik, korps, arbeitszimmer, abteil);

            dialog.showAndWait();
        }
        catch (IOException e) {}
    }
    public static void main(String[] args) {
        launch(args);
    }
}
